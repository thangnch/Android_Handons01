package com.example.bai1_screena;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ScreenB extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_b);

        // 1. Đọc giá trị username truyền từ Activity A sang
        Intent fromA = getIntent();
        String username_fromA = fromA.getStringExtra("username");
        // 2. Set giá trị đó vào lblHello
        TextView lblHello = findViewById(R.id.lblHello);
        lblHello.setText("Hello, " + username_fromA);
    }
}